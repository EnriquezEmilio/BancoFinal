﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Banco.Migrations
{
    /// <inheritdoc />
    public partial class AgregarColumnaIdUsuario : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AlterColumn<int>(
                name: "cbu",
                table: "PlazoFijo",
                type: "int",
                nullable: true,
                oldClrType: typeof(int),
                oldType: "int");

            migrationBuilder.AddColumn<int>(
                name: "idUsuario",
                table: "CajaAhorro",
                type: "int",
                nullable: false,
                defaultValue: 0);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "idUsuario",
                table: "CajaAhorro");

            migrationBuilder.AlterColumn<int>(
                name: "cbu",
                table: "PlazoFijo",
                type: "int",
                nullable: false,
                defaultValue: 0,
                oldClrType: typeof(int),
                oldType: "int",
                oldNullable: true);
        }
    }
}
